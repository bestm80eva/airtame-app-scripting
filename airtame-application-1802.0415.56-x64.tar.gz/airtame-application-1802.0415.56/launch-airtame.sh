#!/bin/bash

cd "$( dirname "${BASH_SOURCE[0]}" )"
LD_LIBRARY_PATH=resources/deps/airtame-core/lib:resources/deps/airtame-encryption/lib ./airtame-application --disable-gpu --enable-transparent-visuals

pkill -9 airtame-streamer airtame-application
