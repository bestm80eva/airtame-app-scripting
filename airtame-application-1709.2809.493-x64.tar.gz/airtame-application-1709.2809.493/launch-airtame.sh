#!/bin/bash

cd "$( dirname "${BASH_SOURCE[0]}" )"
LD_LIBRARY_PATH=resources/app.asar.unpacked/streamer/vendor/airtame-core/lib:resources/app.asar.unpacked/encryption/out/lib ./airtame-application --disable-gpu --enable-transparent-visuals

pkill -9 airtame-streamer airtame-application
